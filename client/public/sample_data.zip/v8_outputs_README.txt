Generated from effective v8: timetable_by_date_and_weekday_REASON_effective_v8.json
Generated at: 2026-02-24T10:58:54
As-of date for completed/remaining: 2026-02-09
Diff: replaced manual reasons for 2/13, 2/19; added reason on 3/12 period2 (kept class).
Scan file lists remaining '手動調整' occurrences.
